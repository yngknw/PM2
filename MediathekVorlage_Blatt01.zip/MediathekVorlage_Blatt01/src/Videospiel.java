
public class Videospiel implements Medium
{
	String _titel;
	String _kommentar;
	String _plattform;
	public Videospiel(String titel, String kommentar, String plattform)
	{
		_titel = titel;
		_kommentar = kommentar;
		_plattform = plattform;
	}

	@Override
	public String getKommentar()
	{
		return _kommentar;
	}

	@Override
	public String getMedienBezeichnung()
	{
		return "Videospiel";
	}

	@Override
	public String getTitel()
	{
		return _titel;
	}
	public String getPlattform()
	{
		return _plattform;
	}
	
	public String getFormatiertenString()
    {
    	return "Titel: " + _titel + "\n" + "Beschreibung: " + _kommentar + "\n" + "Plattform: " + _plattform;
    }

}
