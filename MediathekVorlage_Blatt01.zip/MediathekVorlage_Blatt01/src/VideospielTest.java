import static org.junit.Assert.*;

import org.junit.Test;

public class VideospielTest
{
	private static final String KOMMENTAR = "Kommentar";
	private static final String TITEL = "Titel";
	private static final String BEZEICHNUNG = "Videospiel";
	private static final String PLATTFORM = "Plattform";
	private Videospiel spiel1;
	private Videospiel spiel2;

	public VideospielTest()
	{
		spiel1 = new Videospiel(TITEL, KOMMENTAR, PLATTFORM);
		spiel2 = new Videospiel(TITEL, KOMMENTAR, PLATTFORM);
	}

	@Test
	public void KonstruktorTest()
	{
		assertEquals(TITEL, spiel1.getTitel());
		assertEquals(KOMMENTAR, spiel1.getKommentar());
		assertEquals(BEZEICHNUNG, spiel1.getMedienBezeichnung());
		assertEquals(PLATTFORM, spiel1.getPlattform());
	}

	public void testEquals()
	{
		assertFalse("Mehrere Exemplare des gleichen Spieles sind gleich", spiel1.equals(spiel2));
		assertTrue("Mehrere Exemplare des gleichen Spieles sind ungleich", spiel1.equals(spiel1));
	}

}
